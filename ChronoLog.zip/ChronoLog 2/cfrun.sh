dmd *.d jtask/*.d -ofbin/Debug/run
