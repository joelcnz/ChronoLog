# not work
cp *.d source
cp jtask/*.d source/jtask
../dub
mv tasklog bin/Debug
cd bin/Debug
./tasklog
cd ../..
