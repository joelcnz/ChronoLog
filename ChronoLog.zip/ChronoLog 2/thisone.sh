import std.process;

void main() {
	system("dmd main base control taskman task jtask/*.d -ofbin/Debug/thisone");
}